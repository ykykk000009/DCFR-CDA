import os
os.environ["SCIPY_ARRAY_API"] = "1"

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import random
from dgl.nn.pytorch import GATConv

def set_seed(seed=42):
    """Fix random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

set_seed(42)

class GNN(nn.Module):
    def __init__(self, in_feats, hidden_dim, out_dim, num_heads, k=10, alpha=0.15):
        super(GNN, self).__init__()
        # First GAT layer with multi-head attention
        self.conv1 = GATConv(in_feats, hidden_dim, num_heads, feat_drop=0.6, attn_drop=0.6,
                             residual=True)
        # Second GAT layer, input dim should be num_heads * hidden_dim
        self.conv2 = GATConv(hidden_dim * num_heads, out_dim, 1, feat_drop=0.6, attn_drop=0.6,
                             residual=True)  # Allow zero in-degree nodes

    def forward(self, g, features):
        # Node feature aggregation via GAT
        h = F.relu(self.conv1(g, features))  #
        h = h.flatten(1)
        h = self.conv2(g, h)
        h = h.squeeze(1)

        return h

class RNA_Disease_Model(nn.Module):
    def __init__(self, in_feats, hidden_dim, out_dim, num_heads):
        super(RNA_Disease_Model, self).__init__()
        self.gnn = GNN(in_feats, hidden_dim, out_dim, num_heads)  # GNN encoder

        """Simplified MLP structure"""
        self.fc1 = nn.Linear(out_dim, 128)
        self.bn1 = nn.BatchNorm1d(128)
        self.fc2 = nn.Linear(128, 1)

        # Dropout to prevent overfitting
        self.dropout = nn.Dropout(0.5)
        self.sigmoid = nn.Sigmoid()

    def forward(self, g, features):
        embeddings = self.gnn(g, features)
        return embeddings

    def predict(self, embeddings):
        x = self.fc1(embeddings)
        x = F.relu(self.bn1(x))
        x = self.dropout(x)

        logits = self.fc2(x)
        return logits

def calculate_feature_similarity_cos(embeddings, embeddings2):
    # Normalize embeddings
    embeddings_norm = F.normalize(embeddings, p=2, dim=1)  # [N, D]
    # Compute cosine similarity matrix for all node pairs
    sim_matrix = torch.mm(embeddings_norm, embeddings_norm.T)  # [N, N]
    return sim_matrix

def gumbel_softmax(logits, tau=0.5, hard=False):
    # Generate Gumbel noise
    noise = torch.rand_like(logits).to(logits.device)
    noise = -torch.log(-torch.log(noise + 1e-10) + 1e-10)

    # Add noise and apply softmax
    y = logits + noise
    y = F.softmax(y / tau, dim=-1)

    if hard:
        # Hard selection: return one-hot vector
        _, k = y.max(dim=-1)
        y_hard = torch.zeros_like(y).scatter_(-1, k.unsqueeze(-1), 1.0)
        y = (y_hard - y).detach() + y  # Preserve gradients
    return y

def triplet_contrastive_loss(z_anchor, z_pos, z_neg, margin=0.2):
    # L2 normalization
    z_anchor = F.normalize(z_anchor, dim=1)
    z_pos = F.normalize(z_pos, dim=1)
    z_neg = F.normalize(z_neg, dim=2)

    # Compute positive and negative similarities
    sim_pos = (z_anchor * z_pos).sum(dim=1)
    sim_neg = torch.bmm(z_neg, z_anchor.unsqueeze(2)).squeeze(2)

    # Triplet hinge loss
    triplet_loss = F.relu(sim_neg - sim_pos.unsqueeze(1) + margin)
    return triplet_loss.mean()

def negative_sample_idx(edge_index, labels, pos_idx, tau, f_sim_matrix, k, alpha, beta):
    n = len(labels)
    labels = labels.flatten()
    device = edge_index.device

    # Construct differentiable adjacency matrix
    if not hasattr(edge_index, 'edge_logits'):
        edge_index.edge_logits = torch.randn(edge_index.size(1), 2, requires_grad=True, device=device)
    edge_probs = gumbel_softmax(edge_index.edge_logits, tau=tau)
    adj_values = edge_probs[:, 1]
    adj_matrix = torch.sparse_coo_tensor(edge_index, adj_values, (n, n)).to_dense()
    adj_matrix = (adj_matrix + adj_matrix.T) / 2  # Symmetrize

    # Personalized PageRank (PPR) computation
    labels_one_hot = F.one_hot(torch.arange(n, device=device)).float()
    ppr = labels_one_hot
    for _ in range(k):
        deg = adj_matrix.sum(1, keepdim=True)
        ppr = alpha * labels_one_hot + (1 - alpha) * torch.matmul(adj_matrix / (deg + 1e-8), ppr)

    # Combine similarity with fusion matrix
    rescale = ppr.mean() / f_sim_matrix.mean()
    combined_sim = (1 - beta) * ppr + beta * f_sim_matrix * rescale
    sim_matrix = torch.nan_to_num(torch.exp(-combined_sim / tau))

    # Initialize negative sample index matrix
    neg_samples_idx = torch.full((n, pos_idx.size(1)), -1, dtype=torch.long, device=device)

    # Probability-based negative sampling
    for i in range(n):
        anchor_label = labels[i].item()
        # Negative samples: labels different from anchor
        candidates = [j for j in range(n) if labels[j].item() != anchor_label]
        if candidates:
            sim_scores = sim_matrix[i, candidates].clamp(min=0.0)

            inv_sim = 1.0 / (sim_scores + 1e-8) + 1e-6

            sum_inv = inv_sim.sum()
            if not torch.isfinite(sum_inv) or sum_inv <= 0:
                prob = torch.ones_like(inv_sim, device=device) / inv_sim.numel()
            else:
                prob = inv_sim / sum_inv

            if not torch.isfinite(prob).all():
                prob = torch.ones_like(inv_sim, device=device) / inv_sim.numel()

            # Sample without replacement
            selected_idx = torch.multinomial(prob, num_samples=min(pos_idx.size(1), len(candidates)), replacement=False)
            selected = torch.tensor(candidates)[selected_idx]
            neg_samples_idx[i, :len(selected)] = selected

    # Fill missing positions if not enough negatives
    neg_samples_idx[neg_samples_idx == -1] = 0

    # Compute sampling weights
    D_neg = torch.exp(-combined_sim / tau).clamp(min=1e-6)
    w_matrix = D_neg / D_neg.sum(dim=1, keepdim=True)
    w_neg = w_matrix[torch.arange(n, device=device).unsqueeze(1), neg_samples_idx]

    return w_neg, neg_samples_idx

def positive_sample_idx(edge_index, labels, tau, f_sim_matrix, k, alpha, beta, N):
    """
    Generate positive sample indices for each node.
    Returns:
        sim_matrix: similarity matrix
        pos_samples_idx: positive sample index matrix (n, N)
    """
    n = len(labels)
    labels = labels.flatten()
    device = edge_index.device

    # Construct differentiable adjacency matrix
    if not hasattr(edge_index, 'edge_logits'):
        edge_index.edge_logits = torch.randn(edge_index.size(1), 2, requires_grad=True, device=device)
    edge_probs = gumbel_softmax(edge_index.edge_logits, tau=tau)
    adj_values = edge_probs[:, 1]
    adj_matrix = torch.sparse_coo_tensor(edge_index, adj_values, (n, n)).to_dense()
    adj_matrix = (adj_matrix + adj_matrix.T) / 2  # Symmetrize

    # Personalized PageRank (PPR) computation
    labels_one_hot = F.one_hot(torch.arange(n, device=device)).float()
    ppr = labels_one_hot
    for _ in range(k):
        deg = adj_matrix.sum(1, keepdim=True)
        ppr = alpha * labels_one_hot + (1 - alpha) * torch.matmul(adj_matrix / (deg + 1e-8), ppr)

    # Combine similarity with fusion matrix
    rescale = ppr.mean() / f_sim_matrix.mean()
    combined_sim = (1 - beta) * ppr + beta * f_sim_matrix * rescale
    sim_matrix = torch.nan_to_num(torch.exp(-combined_sim / tau))

    # Initialize positive sample index matrix
    pos_samples_idx = torch.full((n, N), -1, dtype=torch.long, device=device)

    # Probability-based positive sampling
    for i in range(n):
        anchor_label = labels[i].item()
        # Positive samples: same label as anchor
        candidates = [j for j in range(n) if labels[j].item() == anchor_label and j != i]
        if candidates:
            # Compute similarity scores
            sim_scores = sim_matrix[i, candidates].clamp(min=0.0)

            # Normalize probabilities
            eps = 1e-6
            scores_eps = sim_scores + eps
            sum_scores = scores_eps.sum()
            if not torch.isfinite(sum_scores) or sum_scores <= 0:
                prob = torch.ones_like(scores_eps, device=device) / scores_eps.numel()
            else:
                prob = scores_eps / sum_scores

            # Extra safety for NaN/Inf
            if not torch.isfinite(prob).all():
                prob = torch.ones_like(scores_eps, device=device) / scores_eps.numel()

            # Sample without replacement
            selected_idx = torch.multinomial(prob, num_samples=min(N, len(candidates)), replacement=False)
            selected = torch.tensor(candidates, device=device)[selected_idx]

            pos_samples_idx[i, :len(selected)] = selected

    # Fill missing positions if not enough positives
    pos_samples_idx[pos_samples_idx == -1] = 0

    # Compute sampling weights
    D_pos = torch.exp(combined_sim / tau).clamp(min=1e-6)
    w_matrix = D_pos / D_pos.sum(dim=1, keepdim=True)
    w_pos = w_matrix[torch.arange(n, device=device).unsqueeze(1), pos_samples_idx]

    return w_pos, pos_samples_idx
