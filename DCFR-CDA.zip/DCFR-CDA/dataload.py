import os
os.environ["SCIPY_ARRAY_API"] = "1"
import numpy as np
import pandas as pd
import torch
from imblearn.over_sampling import RandomOverSampler
from torch.utils.data import DataLoader, Dataset, Subset
from collections import defaultdict  # Import defaultdict

class CircrnaDataset(Dataset):
    def __init__(self, rna_files, disease_files, assoc_file):
        self.rna_files = rna_files
        self.disease_files = disease_files
        self.assoc_file = assoc_file
        self.rna_features = [pd.read_csv(f, index_col=0).values for f in rna_files]
        self.disease_features = [pd.read_csv(f, index_col=0).values for f in disease_files]
        self.association = pd.read_csv(assoc_file, index_col=0).values
        self.combined_rna_features = np.concatenate(self.rna_features, axis=1)
        self.combined_disease_features = np.concatenate(self.disease_features, axis=1)
        self.features, self.labels = self._init_features_labels()  # Initialize features and labels
        self.oversample_mapping = []

    def _init_features_labels(self):
        # Concatenate features and labels without oversampling
        features, labels = [], []
        for i in range(self.association.shape[0]):
            for j in range(self.association.shape[1]):
                combined_feat = np.concatenate([self.combined_rna_features[i], self.combined_disease_features[j]])
                features.append(combined_feat)
                labels.append(self.association[i, j])
        return np.array(features), np.array(labels)

    def balance_data(self, indices):
        features, labels = [], []
        original_indices = []  # Record original global indices

        for idx in indices:
            i = idx // self.association.shape[1]
            j = idx % self.association.shape[1]
            combined_feat = np.concatenate([
                self.combined_rna_features[i],
                self.combined_disease_features[j]
            ])
            features.append(combined_feat)
            labels.append(self.association[i, j])
            original_indices.append(idx)  # Save original index

        features = np.array(features)
        labels = np.array(labels)
        original_indices = np.array(original_indices)  # Convert to numpy array

        # print(f"Original training samples: {features.shape[0]}, Positives: {np.sum(labels)}, Negatives: {len(labels) - np.sum(labels)}")

        ros = RandomOverSampler(sampling_strategy=0.5, random_state=42)
        features_resampled, labels_resampled = ros.fit_resample(features, labels)

        # Update mapping
        self.oversample_mapping = original_indices[ros.sample_indices_]

        # Shuffle resampled data
        order = np.arange(len(labels_resampled))
        np.random.shuffle(order)
        features_resampled = features_resampled[order]
        labels_resampled = labels_resampled[order]
        self.oversample_mapping = self.oversample_mapping[order]  # Keep mapping aligned

        print(
            f"After oversampling: {features_resampled.shape[0]} samples, Positives: {np.sum(labels_resampled)}, Negatives: {len(labels_resampled) - np.sum(labels_resampled)}")

        # Consistency check
        for idx in np.where(labels_resampled == 1)[0]:
            orig_idx = self.oversample_mapping[idx]
            i = orig_idx // self.association.shape[1]
            j = orig_idx % self.association.shape[1]
            if self.association[i, j] != 1:
                print(
                    f"Mapping error: oversampled sample {idx} maps to (RNA={i},Disease={j}), original label={self.association[i, j]}, expected 1")
                raise ValueError("Mapping error")
        print("Mapping check passed")

        return features_resampled, labels_resampled

    def create_edge_index_for_subset(self, subset_indices):
        """Generate edges from a training subset (only positive samples inside the subset)."""
        # Get labels and original index mapping
        subset_labels = self.labels[subset_indices]

        # Check if indices are valid
        print(len(self.oversample_mapping))
        print(subset_indices)

        if hasattr(self, 'oversample_mapping') and len(self.oversample_mapping) > 0:
            # With oversampling: use oversample_mapping
            subset_mapping = [self.oversample_mapping[i] for i in subset_indices
                              if i < len(self.oversample_mapping)]
        else:
            # Without oversampling: use original indices
            subset_mapping = subset_indices.copy()

        # Precompute positive associations
        num_diseases = self.association.shape[1]
        assoc_coo = np.where(self.association == 1)
        rna_to_diseases = defaultdict(list)
        disease_to_rnas = defaultdict(list)
        rna_connections = 0
        disease_connections = 0

        for i, j in zip(*assoc_coo):
            rna_to_diseases[i].append(j)
            disease_to_rnas[j].append(i)

        # Build edges (adapted to oversampling indices)
        src, dst = [], []
        valid_original_indices = set(subset_mapping)  # All valid original indices for subset
        connection_counts = defaultdict(int)  # Track connection counts for each positive sample

        for oversampled_idx in np.where(subset_labels == 1)[0]:
            if oversampled_idx >= len(subset_mapping):
                continue  # Skip invalid indices caused by oversampling
            original_idx = subset_mapping[oversampled_idx]

            i, j = original_idx // num_diseases, original_idx % num_diseases

            # --- Same RNA connections ---
            for disease_j in rna_to_diseases.get(i, []):
                if disease_j != j:  # Exclude self-connections
                    target_original = i * num_diseases + disease_j
                    if target_original in valid_original_indices:  # Ensure target is in subset
                        # Find all oversampled copies in subset
                        targets = [k for k, orig in enumerate(subset_mapping)
                                   if orig == target_original]
                        if targets:
                            # Randomly pick one copy instead of always the first
                            selected = np.random.choice(targets)
                            src.append(oversampled_idx)
                            dst.append(selected)
                            connection_counts[oversampled_idx] += 1  # Track connections
                            rna_connections += 1
            # --- Same Disease connections ---
            for rna_i in disease_to_rnas.get(j, []):
                if rna_i != i:  # Exclude self-connections
                    target_original = rna_i * num_diseases + j
                    if target_original in valid_original_indices:
                        targets = [k for k, orig in enumerate(subset_mapping)
                                   if orig == target_original]
                        if targets:
                            # Randomly pick one copy instead of always the first
                            selected = np.random.choice(targets)
                            src.append(oversampled_idx)
                            dst.append(selected)
                            connection_counts[oversampled_idx] += 1  # Track connections
                            disease_connections += 1

        """Add self-loop edges"""
        num_nodes = len(subset_indices)
        self_edges = torch.stack([torch.arange(num_nodes), torch.arange(num_nodes)])

        if len(src) > 0:
            rna_disease_edges = torch.unique(
                torch.stack([
                    torch.tensor(src, dtype=torch.long),
                    torch.tensor(dst, dtype=torch.long)
                ]),
                dim=1
            )

            edge_index = torch.cat([self_edges, rna_disease_edges], dim=1)
        else:
            edge_index = self_edges

        return edge_index

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return idx, torch.tensor(self.features[idx], dtype=torch.float32), torch.tensor(self.labels[idx],
                                                                                        dtype=torch.float32).unsqueeze(
            0)
