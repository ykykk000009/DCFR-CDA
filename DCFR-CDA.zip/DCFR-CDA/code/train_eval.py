import itertools

import dgl
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from imblearn.under_sampling import RandomUnderSampler
from sklearn.metrics import precision_recall_curve, roc_curve
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset

from circ_dataset import CircrnaDataset
from experiment_config import set_seed
from metrics_io import append_metrics_row, compute_metrics, save_roc_pr_to_csv
from model import (
    RNA_Disease_Model,
    calculate_feature_similarity_cos,
    triplet_contrastive_loss,
)
from sampling import negative_sample_idx, positive_sample_idx


PARAM_GRID = {
    "hidden_dim": [128],
    "num_heads": [16],
    "lr": [0.001],
    "pretrain_epochs": [600],
    "fine_tune_epochs": [600],
    "batch_size": [128],
    "alpha": [0.3],
    "beta": [0.3],
    "k": [15],
    "tau": [0.5],
    "threshold": [0.5],
}


def iter_param_combinations(param_grid):
    keys = list(param_grid.keys())
    seen = set()
    for values in itertools.product(*(param_grid[key] for key in keys)):
        params = dict(zip(keys, values))
        dedupe_key = tuple((key, params[key]) for key in keys)
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        yield params


def cross_validation(dataset, k_folds, device):
    best_auc = -float("inf")
    best_params = None
    param_combinations = list(iter_param_combinations(PARAM_GRID))
    print(f"Total unique parameter combinations: {len(param_combinations)}")

    for combo_id, params in enumerate(param_combinations, start=1):
        print(f"\n========== Parameter combo {combo_id}/{len(param_combinations)} ==========")
        print(f"Params: {params}")
        set_seed(42)
        auc = cross_validation_with_experiment(params, dataset, k_folds, device)
        print(f"Combo {combo_id} AUC: {auc:.4f}")
        if auc > best_auc:
            best_auc = auc
            best_params = params.copy()

    print("Best hyperparameters:", best_params)
    print("Best AUC:", best_auc)
    return best_auc


def cross_validation_with_experiment(params, dataset, k_folds, device):
    print(
        "Selected hyperparameters - "
        f"Hidden Dim: {params['hidden_dim']}, Num Heads: {params['num_heads']}, "
        f"Learning Rate: {params['lr']}, Pretrain Epochs: {params['pretrain_epochs']}, "
        f"Fine-tune Epochs: {params['fine_tune_epochs']}, Batch Size: {params['batch_size']}, "
        f"alpha: {params['alpha']}, beta: {params['beta']}, k: {params['k']}, "
        f"tau: {params['tau']}, threshold: {params['threshold']}"
    )

    fold_metrics = []
    all_folds_roc = []
    pr_data = []
    recall_data = []
    aupr_folds = []
    filename_suffix = f"hd{params['hidden_dim']}".replace(".", "")
    splitter = StratifiedKFold(n_splits=k_folds, shuffle=True, random_state=42)

    for fold, (train_idx, val_idx) in enumerate(splitter.split(dataset.features, dataset.labels)):
        fold_seed = 42 + fold
        set_seed(fold_seed)
        print(f"================== Fold {fold + 1}/{k_folds} ==================")

        fold_data = _prepare_fold_data(dataset, train_idx, val_idx, fold_seed, params["batch_size"])
        model = RNA_Disease_Model(
            fold_data["input_dim"],
            params["hidden_dim"],
            fold_data["input_dim"],
            params["num_heads"],
        ).to(device)
        optimizer = optim.AdamW(model.parameters(), lr=params["lr"])
        graph = dgl.graph(
            (fold_data["train_edge_index"][0], fold_data["train_edge_index"][1]),
            num_nodes=len(fold_data["train_labels"]),
        ).to(device)

        _pretrain(model, optimizer, graph, fold_data["train_loader"], params, device)
        _fine_tune(model, optimizer, graph, fold_data["train_loader"], params, device)
        metrics, curves = _evaluate(model, fold_data["val_loader"], params["threshold"], device)
        fold_metrics.append(metrics)

        append_metrics_row(
            [
                fold + 1,
                metrics["AUC"],
                metrics["AUPR"],
                metrics["Accuracy"],
                metrics["F1"],
                metrics["Recall"],
                metrics["Precision"],
            ]
        )
        if curves is not None:
            all_folds_roc.append((curves["fpr"], curves["tpr"], metrics["AUC"]))
            pr_data.append((curves["precision"],))
            recall_data.append((curves["recall"],))
            aupr_folds.append(metrics["AUPR"])

        print("Metrics: AUC, AUPR, Accuracy, F1, Recall, Precision")
        print(
            f"Fold {fold + 1}, {metrics['AUC']}, {metrics['AUPR']}, "
            f"{metrics['Accuracy']}, {metrics['F1']}, {metrics['Recall']}, {metrics['Precision']}"
        )

    avg_metrics = {
        metric_name: np.mean([metrics[metric_name] for metrics in fold_metrics])
        for metric_name in ["AUC", "Accuracy", "AUPR", "F1", "Recall", "Precision"]
    }
    for metric_name, value in avg_metrics.items():
        print(f"Average {metric_name}: {value:.4f}")

    if all_folds_roc:
        save_roc_pr_to_csv(all_folds_roc, pr_data, recall_data, aupr_folds, filename_suffix)
    return avg_metrics["AUC"]


def _prepare_fold_data(dataset, train_idx, val_idx, fold_seed, batch_size):
    assert len(set(train_idx).intersection(val_idx)) == 0, "Training and validation sets overlap."
    fold_rng = np.random.default_rng(fold_seed)

    train_dataset = CircrnaDataset(dataset.rna_files, dataset.disease_files, dataset.assoc_file)
    scaler = StandardScaler()
    train_features = scaler.fit_transform(train_dataset.features[train_idx])
    val_features = scaler.transform(train_dataset.features[val_idx])

    train_features, train_labels, train_mapping = _undersample_split(
        train_features,
        train_dataset.labels[train_idx],
        train_idx,
        fold_seed,
        fold_rng,
    )
    val_features, val_labels, val_mapping = _undersample_split(
        val_features,
        train_dataset.labels[val_idx],
        val_idx,
        fold_seed,
        fold_rng,
    )
    _assert_no_leakage(train_idx, val_idx, train_mapping, val_mapping)

    train_dataset.features = train_features
    train_dataset.labels = train_labels
    train_dataset.oversample_mapping = train_mapping
    train_edge_index = train_dataset.create_edge_index_for_subset(np.arange(len(train_labels)))

    print(
        f"Train after resampling: total={len(train_labels)}, "
        f"positive={int(np.sum(train_labels))}, negative={int(len(train_labels) - np.sum(train_labels))}"
    )
    print(
        f"Validation after resampling: total={len(val_labels)}, "
        f"positive={int(np.sum(val_labels))}, negative={int(len(val_labels) - np.sum(val_labels))}"
    )

    return {
        "input_dim": train_features.shape[1],
        "train_labels": train_labels,
        "train_edge_index": train_edge_index,
        "train_loader": _make_loader(train_features, train_labels, batch_size, shuffle=True, seed=fold_seed),
        "val_loader": _make_loader(val_features, val_labels, batch_size, shuffle=False, seed=fold_seed),
    }


def _undersample_split(features, labels, original_indices, seed, rng):
    sampler = RandomUnderSampler(sampling_strategy=1.0, random_state=seed)
    sampled_features, sampled_labels = sampler.fit_resample(features, labels)
    sampled_mapping = original_indices[sampler.sample_indices_]
    order = np.arange(len(sampled_labels))
    rng.shuffle(order)
    return sampled_features[order], sampled_labels[order], sampled_mapping[order]


def _assert_no_leakage(train_idx, val_idx, train_mapping, val_mapping):
    original_overlap = set(train_idx).intersection(set(val_idx))
    resampled_overlap = set(train_mapping).intersection(set(val_mapping))
    val_source_leakage = set(val_mapping).difference(set(val_idx))
    assert not original_overlap, f"Data leakage before resampling: {sorted(original_overlap)[:10]}"
    assert not resampled_overlap, f"Data leakage after resampling: {sorted(resampled_overlap)[:10]}"
    assert not val_source_leakage, f"Validation resampling used non-validation samples: {sorted(val_source_leakage)[:10]}"
    print("Leakage check passed: original_overlap=0, resampled_overlap=0, val_source_leakage=0")


def _make_loader(features, labels, batch_size, shuffle, seed):
    tensor_dataset = TensorDataset(
        torch.arange(len(labels), dtype=torch.long),
        torch.tensor(features, dtype=torch.float32),
        torch.tensor(labels, dtype=torch.float32).unsqueeze(1),
    )
    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(
        tensor_dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        drop_last=shuffle,
        generator=generator if shuffle else None,
    )


def _pretrain(model, optimizer, graph, train_loader, params, device):
    print("==================== Start pretraining =================")
    for epoch in range(params["pretrain_epochs"]):
        model.train()
        total_loss = 0.0
        for batch_nodes, batch_features, batch_labels in train_loader:
            batch_nodes = batch_nodes.to(device).long()
            batch_features = batch_features.to(device)
            batch_labels = batch_labels.to(device)

            subgraph = graph.subgraph(batch_nodes).to(device)
            subgraph.ndata["feat"] = batch_features
            embeddings = model(subgraph, subgraph.ndata["feat"])
            f_sim_matrix = calculate_feature_similarity_cos(embeddings)
            edge_index = torch.stack(subgraph.edges(), dim=0).to(device).long()

            _, pos_idx = positive_sample_idx(
                edge_index=edge_index,
                labels=batch_labels,
                tau=params["tau"],
                f_sim_matrix=f_sim_matrix,
                k=params["k"],
                alpha=params["alpha"],
                beta=params["beta"],
                n_samples=20,
            )
            _, neg_idx = negative_sample_idx(
                edge_index=edge_index,
                labels=batch_labels,
                pos_idx=pos_idx,
                tau=params["tau"],
                f_sim_matrix=f_sim_matrix,
                k=params["k"],
                alpha=params["alpha"],
                beta=params["beta"],
            )

            loss = triplet_contrastive_loss(
                embeddings,
                embeddings[pos_idx].mean(dim=1),
                embeddings[neg_idx],
                margin=0.2,
            )
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        print(f"Pretrain Epoch {epoch + 1}/{params['pretrain_epochs']}, Loss: {total_loss / len(train_loader):.4f}")


def _fine_tune(model, optimizer, graph, train_loader, params, device):
    print("==================== Start fine-tuning =================")
    bce_loss = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([5.0], device=device))

    for epoch in range(params["fine_tune_epochs"]):
        model.train()
        total_loss = 0.0
        for batch_nodes, batch_features, batch_labels in train_loader:
            batch_nodes = batch_nodes.to(device).long()
            batch_features = batch_features.to(device)
            batch_labels = batch_labels.to(device)

            subgraph = graph.subgraph(batch_nodes).to(device)
            subgraph.ndata["feat"] = batch_features
            logits = model.predict(model(subgraph, subgraph.ndata["feat"]))
            loss = bce_loss(logits.view(-1), batch_labels.view(-1))

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        print(f"Fine-tune Epoch {epoch + 1}/{params['fine_tune_epochs']}, Loss: {total_loss / len(train_loader):.4f}")


def _evaluate(model, val_loader, threshold, device):
    print("==================== Evaluation =================")
    model.eval()
    all_probs, all_preds, all_labels = [], [], []

    with torch.no_grad():
        for _, batch_features, batch_labels in val_loader:
            batch_features = batch_features.to(device)
            batch_labels = batch_labels.to(device)
            val_nodes = torch.arange(batch_features.shape[0], device=device)
            subgraph = dgl.graph((val_nodes, val_nodes), num_nodes=batch_features.shape[0]).to(device)
            subgraph.ndata["feat"] = batch_features

            probabilities = torch.sigmoid(model.predict(model(subgraph, subgraph.ndata["feat"])))
            all_probs.append(probabilities.view(-1))
            all_preds.append((probabilities > threshold).float().view(-1))
            all_labels.append(batch_labels.view(-1))

    probs = torch.cat(all_probs).detach().cpu().numpy()
    preds = torch.cat(all_preds).detach().cpu().numpy()
    labels = torch.cat(all_labels).detach().cpu().numpy()

    curves = None
    if len(set(labels)) >= 2:
        fpr, tpr, _ = roc_curve(labels, probs)
        precision, recall, _ = precision_recall_curve(labels, probs)
        curves = {"fpr": fpr, "tpr": tpr, "precision": precision, "recall": recall}
    return compute_metrics(probs, preds, labels), curves
