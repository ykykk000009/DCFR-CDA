import csv
import os

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

DEFAULT_METRICS_FILE = "A1_downsample_prob_eval_metrics.csv"
METRIC_COLUMNS = ["Fold", "AUC", "AUPR", "Accuracy", "F1", "Recall", "Precision"]

def append_metrics_row(data, filename=DEFAULT_METRICS_FILE):
    file_exists = os.path.isfile(filename)
    with open(filename, mode="a", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(METRIC_COLUMNS)
        writer.writerow(data)


def compute_metrics(probs, preds, labels):
    probs = np.asarray(probs).flatten()
    preds = np.asarray(preds).flatten()
    labels = np.asarray(labels).flatten()

    metrics = {
        "Accuracy": accuracy_score(labels, preds),
        "F1": f1_score(labels, preds, zero_division=1),
        "Recall": recall_score(labels, preds, zero_division=1),
        "Precision": precision_score(labels, preds, zero_division=1),
    }
    if len(set(labels)) < 2:
        print("Warning: only one class is present; AUC and AUPR are undefined.")
        metrics.update({"AUC": float("nan"), "AUPR": float("nan")})
        return metrics

    metrics.update(
        {
            "AUC": roc_auc_score(labels, probs),
            "AUPR": average_precision_score(labels, probs),
        }
    )
    return metrics


def save_roc_pr_to_csv(all_folds_roc, pr_data, recall_data, aupr_folds, filename_suffix=""):
    roc_records = []
    for fold, (fpr, tpr, auc) in enumerate(all_folds_roc, start=1):
        for fpr_value, tpr_value in zip(fpr, tpr):
            roc_records.append(
                {"fold": fold, "fpr": fpr_value, "tpr": tpr_value, "auc": auc}
            )
    pd.DataFrame(roc_records).to_csv(f"roc_data_{filename_suffix}.csv", index=False)

    pr_records = []
    for fold, (precision_arr, recall_arr, aupr) in enumerate(
        zip(pr_data, recall_data, aupr_folds), start=1
    ):
        precision_arr = np.ravel(precision_arr)
        recall_arr = np.ravel(recall_arr)
        sort_idx = np.argsort(recall_arr)
        recall_arr = recall_arr[sort_idx]
        precision_arr = precision_arr[sort_idx]
        for precision_value, recall_value in zip(precision_arr, recall_arr):
            pr_records.append(
                {
                    "fold": fold,
                    "recall": float(recall_value),
                    "precision": float(precision_value),
                    "aupr": float(aupr),
                }
            )
    pd.DataFrame(pr_records).to_csv(f"pr_data_{filename_suffix}.csv", index=False)