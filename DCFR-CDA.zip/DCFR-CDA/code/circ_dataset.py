﻿from collections import defaultdict

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


class CircrnaDataset(Dataset):
    def __init__(self, rna_files, disease_files, assoc_file):
        self.rna_files = rna_files
        self.disease_files = disease_files
        self.assoc_file = assoc_file

        self.rna_features = [pd.read_csv(path, index_col=0).values for path in rna_files]
        self.disease_features = [pd.read_csv(path, index_col=0).values for path in disease_files]
        self.association = pd.read_csv(assoc_file, index_col=0).values
        self.num_diseases = self.association.shape[1]

        self.combined_rna_features = np.concatenate(self.rna_features, axis=1)
        self.combined_disease_features = np.concatenate(self.disease_features, axis=1)
        self.features, self.labels = self._init_features_labels()
        self.oversample_mapping = []
        self.rna_to_diseases, self.disease_to_rnas = self._build_association_maps()

    def _init_features_labels(self):
        features, labels = [], []
        for rna_idx in range(self.association.shape[0]):
            for disease_idx in range(self.association.shape[1]):
                features.append(
                    np.concatenate(
                        [
                            self.combined_rna_features[rna_idx],
                            self.combined_disease_features[disease_idx],
                        ]
                    )
                )
                labels.append(self.association[rna_idx, disease_idx])
        return np.asarray(features), np.asarray(labels)

    def _build_association_maps(self):
        rna_to_diseases = defaultdict(list)
        disease_to_rnas = defaultdict(list)
        assoc_rows, assoc_cols = np.where(self.association == 1)
        for rna_idx, disease_idx in zip(assoc_rows, assoc_cols):
            rna_to_diseases[rna_idx].append(disease_idx)
            disease_to_rnas[disease_idx].append(rna_idx)
        return rna_to_diseases, disease_to_rnas

    def create_edge_index_for_subset(self, subset_indices):
        subset_indices = np.asarray(subset_indices)
        subset_labels = self.labels[subset_indices]
        subset_mapping = self._map_subset_to_original_indices(subset_indices)
        valid_original_indices = set(subset_mapping)
        original_to_subset_positions = defaultdict(list)
        for subset_pos, original_idx in enumerate(subset_mapping):
            original_to_subset_positions[original_idx].append(subset_pos)

        src, dst = [], []
        for subset_pos in np.where(subset_labels == 1)[0]:
            if subset_pos >= len(subset_mapping):
                continue
            original_idx = subset_mapping[subset_pos]
            rna_idx = original_idx // self.num_diseases
            disease_idx = original_idx % self.num_diseases
            self._append_connected_samples(
                subset_pos,
                rna_idx,
                disease_idx,
                valid_original_indices,
                original_to_subset_positions,
                src,
                dst,
            )

        num_nodes = len(subset_indices)
        self_edges = torch.stack([torch.arange(num_nodes), torch.arange(num_nodes)])
        if not src:
            return self_edges

        related_edges = torch.unique(
            torch.stack([torch.tensor(src), torch.tensor(dst)]),
            dim=1,
        )
        return torch.cat([self_edges, related_edges], dim=1)

    def _map_subset_to_original_indices(self, subset_indices):
        if len(self.oversample_mapping) == 0:
            return subset_indices.copy()
        return np.asarray(
            [
                self.oversample_mapping[idx]
                for idx in subset_indices
                if idx < len(self.oversample_mapping)
            ]
        )

    def _append_connected_samples(
        self,
        source_pos,
        rna_idx,
        disease_idx,
        valid_original_indices,
        original_to_subset_positions,
        src,
        dst,
    ):
        for connected_disease_idx in self.rna_to_diseases.get(rna_idx, []):
            if connected_disease_idx == disease_idx:
                continue
            target_original = rna_idx * self.num_diseases + connected_disease_idx
            self._append_target_if_present(
                source_pos,
                target_original,
                valid_original_indices,
                original_to_subset_positions,
                src,
                dst,
            )

        for connected_rna_idx in self.disease_to_rnas.get(disease_idx, []):
            if connected_rna_idx == rna_idx:
                continue
            target_original = connected_rna_idx * self.num_diseases + disease_idx
            self._append_target_if_present(
                source_pos,
                target_original,
                valid_original_indices,
                original_to_subset_positions,
                src,
                dst,
            )

    @staticmethod
    def _append_target_if_present(
        source_pos,
        target_original,
        valid_original_indices,
        original_to_subset_positions,
        src,
        dst,
    ):
        if target_original not in valid_original_indices:
            return
        targets = original_to_subset_positions.get(target_original, [])
        if targets:
            src.append(source_pos)
            dst.append(np.random.choice(targets))

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return (
            idx,
            torch.tensor(self.features[idx], dtype=torch.float32),
            torch.tensor(self.labels[idx], dtype=torch.float32).unsqueeze(0),
        )
