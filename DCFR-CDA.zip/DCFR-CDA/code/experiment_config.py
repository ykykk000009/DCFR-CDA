import random

import numpy as np
import torch


DEFAULT_SEED = 42


def set_seed(seed=DEFAULT_SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    torch.set_num_threads(1)


def select_device():
    if not torch.cuda.is_available():
        return torch.device("cpu")
    try:
        probe = torch.ones(1, device="cuda") + 1
        torch.cuda.synchronize()
        return torch.device("cuda")
    except RuntimeError as exc:
        print(f"CUDA is unavailable for this PyTorch/DGL build: {exc}")
        print("Use CPU for this run, or install a PyTorch/DGL build that supports your GPU.")
        return torch.device("cpu")
