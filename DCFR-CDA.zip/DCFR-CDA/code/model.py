import torch
import torch.nn as nn
import torch.nn.functional as F
from dgl.nn.pytorch import GATConv


class GNN(nn.Module):
    def __init__(self, in_feats, hidden_dim, out_dim, num_heads):
        super().__init__()
        self.conv1 = GATConv(
            in_feats,
            hidden_dim,
            num_heads,
            feat_drop=0.6,
            attn_drop=0.6,
            residual=True,
        )
        self.conv2 = GATConv(
            hidden_dim * num_heads,
            out_dim,
            1,
            feat_drop=0.6,
            attn_drop=0.6,
            residual=True,
        )

    def forward(self, graph, features):
        hidden = F.relu(self.conv1(graph, features))
        hidden = hidden.flatten(1)
        hidden = self.conv2(graph, hidden)
        return hidden.squeeze(1)


class RNA_Disease_Model(nn.Module):
    def __init__(self, in_feats, hidden_dim, out_dim, num_heads):
        super().__init__()
        self.gnn = GNN(in_feats, hidden_dim, out_dim, num_heads)
        self.fc1 = nn.Linear(out_dim, 128)
        self.bn1 = nn.BatchNorm1d(128)
        self.dropout = nn.Dropout(0.2)
        self.fc2 = nn.Linear(128, 1)

    def forward(self, graph, features):
        return self.gnn(graph, features)

    def predict(self, embeddings):
        hidden = F.relu(self.bn1(self.fc1(embeddings)))
        hidden = self.dropout(hidden)
        return self.fc2(hidden)


def calculate_feature_similarity_cos(embeddings):
    embeddings_norm = F.normalize(embeddings, p=2, dim=1)
    return torch.mm(embeddings_norm, embeddings_norm.T)


def triplet_contrastive_loss(z_anchor, z_pos, z_neg, margin=0.2):
    z_anchor = F.normalize(z_anchor, dim=1)
    z_pos = F.normalize(z_pos, dim=1)
    z_neg = F.normalize(z_neg, dim=2)

    sim_pos = (z_anchor * z_pos).sum(dim=1)
    sim_neg = torch.bmm(z_neg, z_anchor.unsqueeze(2)).squeeze(2)
    return F.relu(sim_neg - sim_pos.unsqueeze(1) + margin).mean()
