import os
from pathlib import Path

from circ_dataset import CircrnaDataset
from experiment_config import select_device, set_seed
from train_eval import cross_validation


def main():
    os.chdir(Path(__file__).resolve().parent)
    set_seed(42)

    file_combinations = [
        {
            "rna": [
                "circ2Disease4/SVD_RNA_matrix.csv",
                "circ2Disease4/NMF_RNA_matrix.csv",
                "circ2Disease4/MLPF_RNA_matrix.csv",
                "circ2Disease4/CNNF_RNA_matrix.csv",
            ],
            "disease": [
                "circ2Disease4/SVD_Disease_matrix.csv",
                "circ2Disease4/NMF_Disease_matrix.csv",
                "circ2Disease4/MLPF_Disease_matrix.csv",
                "circ2Disease4/CNNF_Disease_matrix.csv",
            ],
        },
    ]
    association_matrix_file = "circ2Disease4/association_matrix.csv"
    device = select_device()

    for i, combo in enumerate(file_combinations, 1):
        print(f"\n{'=' * 50}")
        print(f"Running combination {i}/{len(file_combinations)}")
        print(f"RNA files: {combo['rna']}")
        print(f"Disease files: {combo['disease']}")
        print(f"{'=' * 50}\n")

        dataset = CircrnaDataset(combo["rna"], combo["disease"], association_matrix_file)
        cross_validation(dataset, 5, device)

        print(f"\n{'=' * 50}")
        print(f"Combination {i}/{len(file_combinations)} finished")
        print(f"{'=' * 50}\n")

    print("All file combinations finished.")


if __name__ == "__main__":
    main()
