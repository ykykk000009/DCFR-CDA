import torch
import torch.nn.functional as F


def gumbel_softmax(logits, tau=0.5, hard=False):
    noise = torch.rand_like(logits, device=logits.device)
    noise = -torch.log(-torch.log(noise + 1e-10) + 1e-10)
    y = F.softmax((logits + noise) / tau, dim=-1)

    if hard:
        _, max_idx = y.max(dim=-1)
        y_hard = torch.zeros_like(y).scatter_(-1, max_idx.unsqueeze(-1), 1.0)
        y = (y_hard - y).detach() + y
    return y


def positive_sample_idx(edge_index, labels, tau, f_sim_matrix, k, alpha, beta, n_samples):
    combined_sim = _combined_similarity(edge_index, f_sim_matrix, tau, k, alpha, beta)
    sim_matrix = torch.nan_to_num(torch.exp(-combined_sim / tau))
    labels = labels.flatten()
    n = len(labels)
    device = edge_index.device
    pos_samples_idx = torch.full((n, n_samples), -1, dtype=torch.long, device=device)

    for i in range(n):
        anchor_label = labels[i].item()
        candidates = [j for j in range(n) if labels[j].item() == anchor_label and j != i]
        if not candidates:
            continue

        sim_scores = sim_matrix[i, candidates].clamp(min=0.0)
        scores_eps = sim_scores + 1e-6
        total = scores_eps.sum()
        if not torch.isfinite(total) or total <= 0:
            prob = torch.ones_like(scores_eps, device=device) / scores_eps.numel()
        else:
            prob = scores_eps / total
        if not torch.isfinite(prob).all():
            prob = torch.ones_like(scores_eps, device=device) / scores_eps.numel()

        selected = _sample_candidates(candidates, prob, n_samples, device)
        pos_samples_idx[i, : len(selected)] = selected

    pos_samples_idx[pos_samples_idx == -1] = 0
    weights = _row_weights(torch.exp(combined_sim / tau), pos_samples_idx)
    return weights, pos_samples_idx


def negative_sample_idx(edge_index, labels, pos_idx, tau, f_sim_matrix, k, alpha, beta):
    combined_sim = _combined_similarity(edge_index, f_sim_matrix, tau, k, alpha, beta)
    sim_matrix = torch.nan_to_num(torch.exp(-combined_sim / tau))
    labels = labels.flatten()
    n = len(labels)
    device = edge_index.device
    n_samples = pos_idx.size(1)
    neg_samples_idx = torch.full((n, n_samples), -1, dtype=torch.long, device=device)

    for i in range(n):
        anchor_label = labels[i].item()
        candidates = [j for j in range(n) if labels[j].item() != anchor_label]
        if not candidates:
            continue

        sim_scores = sim_matrix[i, candidates].clamp(min=0.0)
        inv_sim = 1.0 / (sim_scores + 1e-8) + 1e-6
        total = inv_sim.sum()
        if not torch.isfinite(total) or total <= 0:
            prob = torch.ones_like(inv_sim, device=device) / inv_sim.numel()
        else:
            prob = inv_sim / total
        if not torch.isfinite(prob).all():
            prob = torch.ones_like(inv_sim, device=device) / inv_sim.numel()

        selected = _sample_candidates(candidates, prob, n_samples, device)
        neg_samples_idx[i, : len(selected)] = selected

    neg_samples_idx[neg_samples_idx == -1] = 0
    weights = _row_weights(torch.exp(-combined_sim / tau), neg_samples_idx)
    return weights, neg_samples_idx


def _combined_similarity(edge_index, f_sim_matrix, tau, k, alpha, beta):
    n = f_sim_matrix.size(0)
    device = edge_index.device
    if not hasattr(edge_index, "edge_logits"):
        edge_index.edge_logits = torch.randn(edge_index.size(1), 2, requires_grad=True, device=device)
    edge_probs = gumbel_softmax(edge_index.edge_logits, tau=tau)
    adj_values = edge_probs[:, 1]
    adj_matrix = torch.sparse_coo_tensor(edge_index, adj_values, (n, n)).to_dense()
    adj_matrix = (adj_matrix + adj_matrix.T) / 2

    identity = F.one_hot(torch.arange(n, device=device), num_classes=n).float()
    ppr = identity
    for _ in range(k):
        degree = adj_matrix.sum(1, keepdim=True)
        ppr = alpha * identity + (1 - alpha) * torch.matmul(adj_matrix / (degree + 1e-8), ppr)

    rescale = ppr.mean() / f_sim_matrix.mean()
    return (1 - beta) * ppr + beta * f_sim_matrix * rescale


def _sample_candidates(candidates, prob, n_samples, device):
    count = min(n_samples, len(candidates))
    selected_idx = torch.multinomial(prob, num_samples=count, replacement=False)
    return torch.as_tensor(candidates, dtype=torch.long, device=device)[selected_idx]


def _row_weights(values, sample_idx):
    values = values.clamp(min=1e-6)
    weights = values / values.sum(dim=1, keepdim=True)
    rows = torch.arange(values.size(0), device=values.device).unsqueeze(1)
    return weights[rows, sample_idx]
